#pragma once

extern void foo(void);

