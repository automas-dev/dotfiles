#include "name.h"
#include <stdio.h>

void foo() {
	printf("Hello World!\n");
}
